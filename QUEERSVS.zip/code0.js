gdjs.LevelCode = {};
gdjs.LevelCode.localVariables = [];
gdjs.LevelCode.GDPlatform1Objects1= [];
gdjs.LevelCode.GDPlatform1Objects2= [];
gdjs.LevelCode.GDPlatform1Objects3= [];
gdjs.LevelCode.GDPlatform1Objects4= [];
gdjs.LevelCode.GDPlatform1Objects5= [];
gdjs.LevelCode.GDPlatform2Objects1= [];
gdjs.LevelCode.GDPlatform2Objects2= [];
gdjs.LevelCode.GDPlatform2Objects3= [];
gdjs.LevelCode.GDPlatform2Objects4= [];
gdjs.LevelCode.GDPlatform2Objects5= [];
gdjs.LevelCode.GDPlatform3Objects1= [];
gdjs.LevelCode.GDPlatform3Objects2= [];
gdjs.LevelCode.GDPlatform3Objects3= [];
gdjs.LevelCode.GDPlatform3Objects4= [];
gdjs.LevelCode.GDPlatform3Objects5= [];
gdjs.LevelCode.GDPlatform4Objects1= [];
gdjs.LevelCode.GDPlatform4Objects2= [];
gdjs.LevelCode.GDPlatform4Objects3= [];
gdjs.LevelCode.GDPlatform4Objects4= [];
gdjs.LevelCode.GDPlatform4Objects5= [];
gdjs.LevelCode.GDPortalObjects1= [];
gdjs.LevelCode.GDPortalObjects2= [];
gdjs.LevelCode.GDPortalObjects3= [];
gdjs.LevelCode.GDPortalObjects4= [];
gdjs.LevelCode.GDPortalObjects5= [];
gdjs.LevelCode.GDCheckpointObjects1= [];
gdjs.LevelCode.GDCheckpointObjects2= [];
gdjs.LevelCode.GDCheckpointObjects3= [];
gdjs.LevelCode.GDCheckpointObjects4= [];
gdjs.LevelCode.GDCheckpointObjects5= [];
gdjs.LevelCode.GDLadderObjects1= [];
gdjs.LevelCode.GDLadderObjects2= [];
gdjs.LevelCode.GDLadderObjects3= [];
gdjs.LevelCode.GDLadderObjects4= [];
gdjs.LevelCode.GDLadderObjects5= [];
gdjs.LevelCode.GDFlyObjects1= [];
gdjs.LevelCode.GDFlyObjects2= [];
gdjs.LevelCode.GDFlyObjects3= [];
gdjs.LevelCode.GDFlyObjects4= [];
gdjs.LevelCode.GDFlyObjects5= [];
gdjs.LevelCode.GDCoinObjects1= [];
gdjs.LevelCode.GDCoinObjects2= [];
gdjs.LevelCode.GDCoinObjects3= [];
gdjs.LevelCode.GDCoinObjects4= [];
gdjs.LevelCode.GDCoinObjects5= [];
gdjs.LevelCode.GDMonsterParticlesObjects1= [];
gdjs.LevelCode.GDMonsterParticlesObjects2= [];
gdjs.LevelCode.GDMonsterParticlesObjects3= [];
gdjs.LevelCode.GDMonsterParticlesObjects4= [];
gdjs.LevelCode.GDMonsterParticlesObjects5= [];
gdjs.LevelCode.GDCoinParticlesObjects1= [];
gdjs.LevelCode.GDCoinParticlesObjects2= [];
gdjs.LevelCode.GDCoinParticlesObjects3= [];
gdjs.LevelCode.GDCoinParticlesObjects4= [];
gdjs.LevelCode.GDCoinParticlesObjects5= [];
gdjs.LevelCode.GDDoorParticlesObjects1= [];
gdjs.LevelCode.GDDoorParticlesObjects2= [];
gdjs.LevelCode.GDDoorParticlesObjects3= [];
gdjs.LevelCode.GDDoorParticlesObjects4= [];
gdjs.LevelCode.GDDoorParticlesObjects5= [];
gdjs.LevelCode.GDDustParticleObjects1= [];
gdjs.LevelCode.GDDustParticleObjects2= [];
gdjs.LevelCode.GDDustParticleObjects3= [];
gdjs.LevelCode.GDDustParticleObjects4= [];
gdjs.LevelCode.GDDustParticleObjects5= [];
gdjs.LevelCode.GDCloudsObjects1= [];
gdjs.LevelCode.GDCloudsObjects2= [];
gdjs.LevelCode.GDCloudsObjects3= [];
gdjs.LevelCode.GDCloudsObjects4= [];
gdjs.LevelCode.GDCloudsObjects5= [];
gdjs.LevelCode.GDBackgroundPlantsObjects1= [];
gdjs.LevelCode.GDBackgroundPlantsObjects2= [];
gdjs.LevelCode.GDBackgroundPlantsObjects3= [];
gdjs.LevelCode.GDBackgroundPlantsObjects4= [];
gdjs.LevelCode.GDBackgroundPlantsObjects5= [];
gdjs.LevelCode.GDLeftBoundaryObjects1= [];
gdjs.LevelCode.GDLeftBoundaryObjects2= [];
gdjs.LevelCode.GDLeftBoundaryObjects3= [];
gdjs.LevelCode.GDLeftBoundaryObjects4= [];
gdjs.LevelCode.GDLeftBoundaryObjects5= [];
gdjs.LevelCode.GDRightBoundaryObjects1= [];
gdjs.LevelCode.GDRightBoundaryObjects2= [];
gdjs.LevelCode.GDRightBoundaryObjects3= [];
gdjs.LevelCode.GDRightBoundaryObjects4= [];
gdjs.LevelCode.GDRightBoundaryObjects5= [];
gdjs.LevelCode.GDTopBoundaryObjects1= [];
gdjs.LevelCode.GDTopBoundaryObjects2= [];
gdjs.LevelCode.GDTopBoundaryObjects3= [];
gdjs.LevelCode.GDTopBoundaryObjects4= [];
gdjs.LevelCode.GDTopBoundaryObjects5= [];
gdjs.LevelCode.GDBottomBoundaryObjects1= [];
gdjs.LevelCode.GDBottomBoundaryObjects2= [];
gdjs.LevelCode.GDBottomBoundaryObjects3= [];
gdjs.LevelCode.GDBottomBoundaryObjects4= [];
gdjs.LevelCode.GDBottomBoundaryObjects5= [];
gdjs.LevelCode.GDBoundaryJumpThroughObjects1= [];
gdjs.LevelCode.GDBoundaryJumpThroughObjects2= [];
gdjs.LevelCode.GDBoundaryJumpThroughObjects3= [];
gdjs.LevelCode.GDBoundaryJumpThroughObjects4= [];
gdjs.LevelCode.GDBoundaryJumpThroughObjects5= [];
gdjs.LevelCode.GDMoonObjects1= [];
gdjs.LevelCode.GDMoonObjects2= [];
gdjs.LevelCode.GDMoonObjects3= [];
gdjs.LevelCode.GDMoonObjects4= [];
gdjs.LevelCode.GDMoonObjects5= [];
gdjs.LevelCode.GDEndScreenBackgroundObjects1= [];
gdjs.LevelCode.GDEndScreenBackgroundObjects2= [];
gdjs.LevelCode.GDEndScreenBackgroundObjects3= [];
gdjs.LevelCode.GDEndScreenBackgroundObjects4= [];
gdjs.LevelCode.GDEndScreenBackgroundObjects5= [];
gdjs.LevelCode.GDEndScreenHeaderObjects1= [];
gdjs.LevelCode.GDEndScreenHeaderObjects2= [];
gdjs.LevelCode.GDEndScreenHeaderObjects3= [];
gdjs.LevelCode.GDEndScreenHeaderObjects4= [];
gdjs.LevelCode.GDEndScreenHeaderObjects5= [];
gdjs.LevelCode.GDEndScreenBestTextObjects1= [];
gdjs.LevelCode.GDEndScreenBestTextObjects2= [];
gdjs.LevelCode.GDEndScreenBestTextObjects3= [];
gdjs.LevelCode.GDEndScreenBestTextObjects4= [];
gdjs.LevelCode.GDEndScreenBestTextObjects5= [];
gdjs.LevelCode.GDEndScreenChallengeTextObjects1= [];
gdjs.LevelCode.GDEndScreenChallengeTextObjects2= [];
gdjs.LevelCode.GDEndScreenChallengeTextObjects3= [];
gdjs.LevelCode.GDEndScreenChallengeTextObjects4= [];
gdjs.LevelCode.GDEndScreenChallengeTextObjects5= [];
gdjs.LevelCode.GDJoystickObjects1= [];
gdjs.LevelCode.GDJoystickObjects2= [];
gdjs.LevelCode.GDJoystickObjects3= [];
gdjs.LevelCode.GDJoystickObjects4= [];
gdjs.LevelCode.GDJoystickObjects5= [];
gdjs.LevelCode.GDJumpButtonObjects1= [];
gdjs.LevelCode.GDJumpButtonObjects2= [];
gdjs.LevelCode.GDJumpButtonObjects3= [];
gdjs.LevelCode.GDJumpButtonObjects4= [];
gdjs.LevelCode.GDJumpButtonObjects5= [];
gdjs.LevelCode.GDTrumpObjects1= [];
gdjs.LevelCode.GDTrumpObjects2= [];
gdjs.LevelCode.GDTrumpObjects3= [];
gdjs.LevelCode.GDTrumpObjects4= [];
gdjs.LevelCode.GDTrumpObjects5= [];
gdjs.LevelCode.GDYellowJellyButtonObjects1= [];
gdjs.LevelCode.GDYellowJellyButtonObjects2= [];
gdjs.LevelCode.GDYellowJellyButtonObjects3= [];
gdjs.LevelCode.GDYellowJellyButtonObjects4= [];
gdjs.LevelCode.GDYellowJellyButtonObjects5= [];
gdjs.LevelCode.GDBackgroundPlants2Objects1= [];
gdjs.LevelCode.GDBackgroundPlants2Objects2= [];
gdjs.LevelCode.GDBackgroundPlants2Objects3= [];
gdjs.LevelCode.GDBackgroundPlants2Objects4= [];
gdjs.LevelCode.GDBackgroundPlants2Objects5= [];
gdjs.LevelCode.GDFly2Objects1= [];
gdjs.LevelCode.GDFly2Objects2= [];
gdjs.LevelCode.GDFly2Objects3= [];
gdjs.LevelCode.GDFly2Objects4= [];
gdjs.LevelCode.GDFly2Objects5= [];
gdjs.LevelCode.GDNewSpriteObjects1= [];
gdjs.LevelCode.GDNewSpriteObjects2= [];
gdjs.LevelCode.GDNewSpriteObjects3= [];
gdjs.LevelCode.GDNewSpriteObjects4= [];
gdjs.LevelCode.GDNewSpriteObjects5= [];
gdjs.LevelCode.GDheart1Objects1= [];
gdjs.LevelCode.GDheart1Objects2= [];
gdjs.LevelCode.GDheart1Objects3= [];
gdjs.LevelCode.GDheart1Objects4= [];
gdjs.LevelCode.GDheart1Objects5= [];
gdjs.LevelCode.GDheart2Objects1= [];
gdjs.LevelCode.GDheart2Objects2= [];
gdjs.LevelCode.GDheart2Objects3= [];
gdjs.LevelCode.GDheart2Objects4= [];
gdjs.LevelCode.GDheart2Objects5= [];
gdjs.LevelCode.GDheart3Objects1= [];
gdjs.LevelCode.GDheart3Objects2= [];
gdjs.LevelCode.GDheart3Objects3= [];
gdjs.LevelCode.GDheart3Objects4= [];
gdjs.LevelCode.GDheart3Objects5= [];
gdjs.LevelCode.GDNewSprite2Objects1= [];
gdjs.LevelCode.GDNewSprite2Objects2= [];
gdjs.LevelCode.GDNewSprite2Objects3= [];
gdjs.LevelCode.GDNewSprite2Objects4= [];
gdjs.LevelCode.GDNewSprite2Objects5= [];
gdjs.LevelCode.GDPixelHeartBarObjects1= [];
gdjs.LevelCode.GDPixelHeartBarObjects2= [];
gdjs.LevelCode.GDPixelHeartBarObjects3= [];
gdjs.LevelCode.GDPixelHeartBarObjects4= [];
gdjs.LevelCode.GDPixelHeartBarObjects5= [];
gdjs.LevelCode.GDEndScreenSubHeaderObjects1= [];
gdjs.LevelCode.GDEndScreenSubHeaderObjects2= [];
gdjs.LevelCode.GDEndScreenSubHeaderObjects3= [];
gdjs.LevelCode.GDEndScreenSubHeaderObjects4= [];
gdjs.LevelCode.GDEndScreenSubHeaderObjects5= [];
gdjs.LevelCode.GDEndScreenRetryTextObjects1= [];
gdjs.LevelCode.GDEndScreenRetryTextObjects2= [];
gdjs.LevelCode.GDEndScreenRetryTextObjects3= [];
gdjs.LevelCode.GDEndScreenRetryTextObjects4= [];
gdjs.LevelCode.GDEndScreenRetryTextObjects5= [];
gdjs.LevelCode.GDRetryButtonObjects1= [];
gdjs.LevelCode.GDRetryButtonObjects2= [];
gdjs.LevelCode.GDRetryButtonObjects3= [];
gdjs.LevelCode.GDRetryButtonObjects4= [];
gdjs.LevelCode.GDRetryButtonObjects5= [];
gdjs.LevelCode.GDPRIDE_9595POWERObjects1= [];
gdjs.LevelCode.GDPRIDE_9595POWERObjects2= [];
gdjs.LevelCode.GDPRIDE_9595POWERObjects3= [];
gdjs.LevelCode.GDPRIDE_9595POWERObjects4= [];
gdjs.LevelCode.GDPRIDE_9595POWERObjects5= [];
gdjs.LevelCode.GDDonateObjects1= [];
gdjs.LevelCode.GDDonateObjects2= [];
gdjs.LevelCode.GDDonateObjects3= [];
gdjs.LevelCode.GDDonateObjects4= [];
gdjs.LevelCode.GDDonateObjects5= [];
gdjs.LevelCode.GDPlayerObjects1= [];
gdjs.LevelCode.GDPlayerObjects2= [];
gdjs.LevelCode.GDPlayerObjects3= [];
gdjs.LevelCode.GDPlayerObjects4= [];
gdjs.LevelCode.GDPlayerObjects5= [];
gdjs.LevelCode.GDPlayer2Objects1= [];
gdjs.LevelCode.GDPlayer2Objects2= [];
gdjs.LevelCode.GDPlayer2Objects3= [];
gdjs.LevelCode.GDPlayer2Objects4= [];
gdjs.LevelCode.GDPlayer2Objects5= [];


gdjs.LevelCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.LevelCode.GDJumpButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDJumpButtonObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDJumpButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDJumpButtonObjects3[k] = gdjs.LevelCode.GDJumpButtonObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDJumpButtonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17058124);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDJumpButtonObjects3 */
{for(var i = 0, len = gdjs.LevelCode.GDJumpButtonObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDJumpButtonObjects3[i].setColor("74;74;74");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.LevelCode.GDJumpButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDJumpButtonObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDJumpButtonObjects2[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDJumpButtonObjects2[k] = gdjs.LevelCode.GDJumpButtonObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDJumpButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17059508);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDJumpButtonObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDJumpButtonObjects2[i].setColor("255;255;255");
}
}}

}


};gdjs.LevelCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.LevelCode.GDJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.LevelCode.GDJumpButtonObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDJumpButtonObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDJoystickObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.LevelCode.eventsList2 = function(runtimeScene) {

{



}


{


gdjs.LevelCode.eventsList1(runtimeScene);
}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDDustParticleObjects2Objects = Hashtable.newFrom({"DustParticle": gdjs.LevelCode.GDDustParticleObjects2});
gdjs.LevelCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17061852);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Player__IsSteppingOnFloor.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17063044);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
gdjs.LevelCode.GDDustParticleObjects2.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets/audio/grass.mp3", 1, false, 20, gdjs.randomFloatInRange(0.7, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDDustParticleObjects2Objects, (( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getAABBCenterX()), (( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getAABBBottom()), "");
}{for(var i = 0, len = gdjs.LevelCode.GDDustParticleObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDDustParticleObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.LevelCode.GDDustParticleObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDDustParticleObjects2[i].setAngle(270);
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs.LevelCode.GDCheckpointObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCheckpointObjects3Objects = Hashtable.newFrom({"Checkpoint": gdjs.LevelCode.GDCheckpointObjects3});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.LevelCode.GDCheckpointObjects2, gdjs.LevelCode.GDCheckpointObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCheckpointObjects3Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDCheckpointObjects3 */
{for(var i = 0, len = gdjs.LevelCode.GDCheckpointObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDCheckpointObjects3[i].setAnimationName("InActive");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LevelCode.GDCheckpointObjects2 */
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects, (( gdjs.LevelCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDCheckpointObjects2[0].getPointX("")), (( gdjs.LevelCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDCheckpointObjects2[0].getPointY("")), "Checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LevelCode.GDCheckpointObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDCheckpointObjects2[i].setAnimationName("Activate");
}
}}

}


};gdjs.LevelCode.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects3);
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects3Objects, (( gdjs.LevelCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.LevelCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects3[0].getPointY("")), "Checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.LevelCode.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCheckpointObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDCheckpointObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDCheckpointObjects2[i].isCurrentAnimationName("Activate")) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDCheckpointObjects2[k] = gdjs.LevelCode.GDCheckpointObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDCheckpointObjects2.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "checkpoint.mp3", false, 50, 1);
}
{ //Subevents
gdjs.LevelCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.LevelCode.GDCoinObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCoinParticlesObjects2Objects = Hashtable.newFrom({"CoinParticles": gdjs.LevelCode.GDCoinParticlesObjects2});
gdjs.LevelCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.LevelCode.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDCoinObjects2 */
gdjs.LevelCode.GDCoinParticlesObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCoinParticlesObjects2Objects, (( gdjs.LevelCode.GDCoinObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDCoinObjects2[0].getCenterXInScene()), (( gdjs.LevelCode.GDCoinObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDCoinObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.LevelCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.mp3", false, 50, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.LevelCode.GDCoinObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCoinParticlesObjects2Objects = Hashtable.newFrom({"CoinParticles": gdjs.LevelCode.GDCoinParticlesObjects2});
gdjs.LevelCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.LevelCode.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.LevelCode.GDPlayer2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDCoinObjects2 */
gdjs.LevelCode.GDCoinParticlesObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDCoinParticlesObjects2Objects, (( gdjs.LevelCode.GDCoinObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDCoinObjects2[0].getCenterXInScene()), (( gdjs.LevelCode.GDCoinObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDCoinObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.LevelCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.mp3", false, 50, 1);
}}

}


};gdjs.LevelCode.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].returnVariable(gdjs.LevelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}}

}


};gdjs.LevelCode.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.LevelCode.GDPlayer2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayer2Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayer2Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayer2Objects2[k] = gdjs.LevelCode.GDPlayer2Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayer2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDPlayer2Objects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayer2Objects2[i].returnVariable(gdjs.LevelCode.GDPlayer2Objects2[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.LevelCode.eventsList10 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList3(runtimeScene);
}


{


gdjs.LevelCode.eventsList5(runtimeScene);
}


{


gdjs.LevelCode.eventsList6(runtimeScene);
}


{


gdjs.LevelCode.eventsList7(runtimeScene);
}


{


gdjs.LevelCode.eventsList8(runtimeScene);
}


{


gdjs.LevelCode.eventsList9(runtimeScene);
}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.LevelCode.GDFlyObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.LevelCode.GDFlyObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects3Objects = Hashtable.newFrom({"Fly": gdjs.LevelCode.GDFlyObjects3});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});
gdjs.LevelCode.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects2, gdjs.LevelCode.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LevelCode.GDFlyObjects2, gdjs.LevelCode.GDFlyObjects3);

/* Reuse gdjs.LevelCode.GDPlayerObjects3 */
{gdjs.evtsExt__Enemy__TriggerFlyDeath.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects3Objects, "RectangleMovement", "ShakeObject_PositionAngle", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects3Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17081460);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PixelHeartBar"), gdjs.LevelCode.GDPixelHeartBarObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDPixelHeartBarObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPixelHeartBarObjects2[i].SetValue(gdjs.LevelCode.GDPixelHeartBarObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Hit 4.aac", false, 80, 1);
}}

}


};gdjs.LevelCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.LevelCode.GDFlyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__Enemy__IsFlyDead.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.LevelCode.GDFlyObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.LevelCode.GDFlyObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects3Objects = Hashtable.newFrom({"Fly": gdjs.LevelCode.GDFlyObjects3});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects3Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects3});
gdjs.LevelCode.eventsList13 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayer2Objects2, gdjs.LevelCode.GDPlayer2Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayer2Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayer2Objects3[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayer2Objects3[k] = gdjs.LevelCode.GDPlayer2Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayer2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LevelCode.GDFlyObjects2, gdjs.LevelCode.GDFlyObjects3);

/* Reuse gdjs.LevelCode.GDPlayer2Objects3 */
{gdjs.evtsExt__Enemy__TriggerFlyDeath.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects3Objects, "RectangleMovement", "ShakeObject_PositionAngle", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects3Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayer2Objects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayer2Objects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayer2Objects2[k] = gdjs.LevelCode.GDPlayer2Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayer2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17086508);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PixelHeartBar"), gdjs.LevelCode.GDPixelHeartBarObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDPixelHeartBarObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPixelHeartBarObjects2[i].SetValue(gdjs.LevelCode.GDPixelHeartBarObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Hit 4.aac", false, 80, 1);
}}

}


};gdjs.LevelCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.LevelCode.GDFlyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.LevelCode.GDPlayer2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__Enemy__IsFlyDead.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDFlyObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.LevelCode.GDBackgroundPlantsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.LevelCode.GDFlyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDFlyObjects1[i].getY() > (( gdjs.LevelCode.GDBackgroundPlantsObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBackgroundPlantsObjects1[0].getAABBBottom()) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDFlyObjects1[k] = gdjs.LevelCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDFlyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDFlyObjects1 */
{for(var i = 0, len = gdjs.LevelCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDFlyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.LevelCode.eventsList16 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList12(runtimeScene);
}


{


gdjs.LevelCode.eventsList14(runtimeScene);
}


{


gdjs.LevelCode.eventsList15(runtimeScene);
}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDTrumpObjects3Objects = Hashtable.newFrom({"Trump": gdjs.LevelCode.GDTrumpObjects3});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDMonsterParticlesObjects4Objects = Hashtable.newFrom({"MonsterParticles": gdjs.LevelCode.GDMonsterParticlesObjects4});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});
gdjs.LevelCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayerObjects4[k] = gdjs.LevelCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
gdjs.copyArray(gdjs.LevelCode.GDTrumpObjects3, gdjs.LevelCode.GDTrumpObjects4);

gdjs.LevelCode.GDMonsterParticlesObjects4.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDTrumpObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDTrumpObjects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDMonsterParticlesObjects4Objects, (( gdjs.LevelCode.GDTrumpObjects4.length === 0 ) ? 0 :gdjs.LevelCode.GDTrumpObjects4[0].getCenterXInScene()), (( gdjs.LevelCode.GDTrumpObjects4.length === 0 ) ? 0 :gdjs.LevelCode.GDTrumpObjects4[0].getCenterYInScene()), "");
}{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects4Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDPlayerObjects3 */
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LevelCode.eventsList18 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.LevelCode.GDTrumpObjects3, gdjs.LevelCode.GDTrumpObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDTrumpObjects4.length;i<l;++i) {
    if ( gdjs.LevelCode.GDTrumpObjects4[i].getBehavior("MonsterEnemy").IsOnFire((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDTrumpObjects4[k] = gdjs.LevelCode.GDTrumpObjects4[i];
        ++k;
    }
}
gdjs.LevelCode.GDTrumpObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);

{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

/* Reuse gdjs.LevelCode.GDTrumpObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDTrumpObjects3.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDTrumpObjects3[i].getBehavior("MonsterEnemy").IsOnFire((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDTrumpObjects3[k] = gdjs.LevelCode.GDTrumpObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDTrumpObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Trump"), gdjs.LevelCode.GDTrumpObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects3Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDTrumpObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDTrumpObjects2Objects = Hashtable.newFrom({"Trump": gdjs.LevelCode.GDTrumpObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects3Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects3});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDMonsterParticlesObjects3Objects = Hashtable.newFrom({"MonsterParticles": gdjs.LevelCode.GDMonsterParticlesObjects3});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects3Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects3});
gdjs.LevelCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayer2Objects2, gdjs.LevelCode.GDPlayer2Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayer2Objects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayer2Objects3[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayer2Objects3[k] = gdjs.LevelCode.GDPlayer2Objects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayer2Objects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelCode.GDPlayer2Objects3 */
gdjs.copyArray(gdjs.LevelCode.GDTrumpObjects2, gdjs.LevelCode.GDTrumpObjects3);

gdjs.LevelCode.GDMonsterParticlesObjects3.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDTrumpObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDTrumpObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDMonsterParticlesObjects3Objects, (( gdjs.LevelCode.GDTrumpObjects3.length === 0 ) ? 0 :gdjs.LevelCode.GDTrumpObjects3[0].getCenterXInScene()), (( gdjs.LevelCode.GDTrumpObjects3.length === 0 ) ? 0 :gdjs.LevelCode.GDTrumpObjects3[0].getCenterYInScene()), "");
}{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects3Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayer2Objects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPlayer2Objects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPlayer2Objects2[k] = gdjs.LevelCode.GDPlayer2Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayer2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17100356);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PixelHeartBar"), gdjs.LevelCode.GDPixelHeartBarObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDPixelHeartBarObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPixelHeartBarObjects2[i].SetValue(gdjs.LevelCode.GDPixelHeartBarObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LevelCode.eventsList21 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.LevelCode.GDTrumpObjects2, gdjs.LevelCode.GDTrumpObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDTrumpObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDTrumpObjects3[i].getBehavior("MonsterEnemy").IsOnFire((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDTrumpObjects3[k] = gdjs.LevelCode.GDTrumpObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDTrumpObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LevelCode.GDPlayer2Objects2, gdjs.LevelCode.GDPlayer2Objects3);

{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

/* Reuse gdjs.LevelCode.GDTrumpObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDTrumpObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDTrumpObjects2[i].getBehavior("MonsterEnemy").IsOnFire((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDTrumpObjects2[k] = gdjs.LevelCode.GDTrumpObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDTrumpObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.LevelCode.GDPlayer2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Trump"), gdjs.LevelCode.GDTrumpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDTrumpObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList21(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.LevelCode.eventsList23 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList19(runtimeScene);
}


{


gdjs.LevelCode.eventsList22(runtimeScene);
}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.LevelCode.GDPortalObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.LevelCode.GDPortalObjects2});
gdjs.LevelCode.eventsList24 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
/* Reuse gdjs.LevelCode.GDPortalObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].activateBehavior("PlatformerObject", false);
}
}{gdjs.evtsExt__Player__AnimateFallingIntoPortal.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects, "Tween", gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LevelCode.eventsList25 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList24(runtimeScene);
}


};gdjs.LevelCode.eventsList26 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.LevelCode.GDEndScreenSubHeaderObjects4);
{for(var i = 0, len = gdjs.LevelCode.GDEndScreenSubHeaderObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenSubHeaderObjects4[i].setString("You got " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + " points!");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 950;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.LevelCode.GDEndScreenBestTextObjects4);
{for(var i = 0, len = gdjs.LevelCode.GDEndScreenBestTextObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenBestTextObjects4[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 950;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.LevelCode.GDEndScreenChallengeTextObjects3);
{for(var i = 0, len = gdjs.LevelCode.GDEndScreenChallengeTextObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenChallengeTextObjects3[i].hide();
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDEndScreenBackgroundObjects2Objects = Hashtable.newFrom({"EndScreenBackground": gdjs.LevelCode.GDEndScreenBackgroundObjects2});
gdjs.LevelCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17106620);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList26(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.LevelCode.GDEndScreenBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.LevelCode.GDEndScreenBestTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.LevelCode.GDEndScreenChallengeTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenHeader"), gdjs.LevelCode.GDEndScreenHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.LevelCode.GDEndScreenRetryTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.LevelCode.GDEndScreenSubHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.LevelCode.GDRetryButtonObjects2);
{gdjs.evtsExt__UserInterface__StretchToFillScreen.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDEndScreenBackgroundObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LevelCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenBackgroundObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenHeaderObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenSubHeaderObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenSubHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenBestTextObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenBestTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenChallengeTextObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenChallengeTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenRetryTextObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenRetryTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDRetryButtonObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDRetryButtonObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
}}

}


};gdjs.LevelCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.LevelCode.GDRetryButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDRetryButtonObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDRetryButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDRetryButtonObjects1[k] = gdjs.LevelCode.GDRetryButtonObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDRetryButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "SelectCharacter", false);
}}

}


};gdjs.LevelCode.eventsList29 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList27(runtimeScene);
}


{


gdjs.LevelCode.eventsList28(runtimeScene);
}


};gdjs.LevelCode.eventsList30 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.LevelCode.GDEndScreenBackgroundObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "EndScreen");
}{for(var i = 0, len = gdjs.LevelCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenBackgroundObjects2[i].setOpacity(130);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.LevelCode.GDPortalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17103772);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}
{ //Subevents
gdjs.LevelCode.eventsList25(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndScreen");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.LevelCode.GDPortalObjects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects2});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.LevelCode.GDPortalObjects2});
gdjs.LevelCode.eventsList31 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LevelCode.GDPlayer2Objects2 */
/* Reuse gdjs.LevelCode.GDPortalObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayer2Objects2[i].activateBehavior("PlatformerObject", false);
}
}{gdjs.evtsExt__Player__AnimateFallingIntoPortal.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects, "Tween", gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LevelCode.eventsList32 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList31(runtimeScene);
}


};gdjs.LevelCode.eventsList33 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.LevelCode.GDEndScreenSubHeaderObjects4);
{for(var i = 0, len = gdjs.LevelCode.GDEndScreenSubHeaderObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenSubHeaderObjects4[i].setString("You got " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + " points!");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 950;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.LevelCode.GDEndScreenBestTextObjects4);
{for(var i = 0, len = gdjs.LevelCode.GDEndScreenBestTextObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenBestTextObjects4[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 950;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.LevelCode.GDEndScreenChallengeTextObjects3);
{for(var i = 0, len = gdjs.LevelCode.GDEndScreenChallengeTextObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenChallengeTextObjects3[i].hide();
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDEndScreenBackgroundObjects2Objects = Hashtable.newFrom({"EndScreenBackground": gdjs.LevelCode.GDEndScreenBackgroundObjects2});
gdjs.LevelCode.eventsList34 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17118988);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList33(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.LevelCode.GDEndScreenBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.LevelCode.GDEndScreenBestTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.LevelCode.GDEndScreenChallengeTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenHeader"), gdjs.LevelCode.GDEndScreenHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.LevelCode.GDEndScreenRetryTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.LevelCode.GDEndScreenSubHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.LevelCode.GDRetryButtonObjects2);
{gdjs.evtsExt__UserInterface__StretchToFillScreen.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDEndScreenBackgroundObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LevelCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenBackgroundObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenHeaderObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenSubHeaderObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenSubHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenBestTextObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenBestTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenChallengeTextObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenChallengeTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDEndScreenRetryTextObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenRetryTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LevelCode.GDRetryButtonObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDRetryButtonObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
}}

}


};gdjs.LevelCode.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.LevelCode.GDRetryButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDRetryButtonObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDRetryButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDRetryButtonObjects1[k] = gdjs.LevelCode.GDRetryButtonObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDRetryButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "SelectCharacter", false);
}}

}


};gdjs.LevelCode.eventsList36 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList34(runtimeScene);
}


{


gdjs.LevelCode.eventsList35(runtimeScene);
}


};gdjs.LevelCode.eventsList37 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.LevelCode.GDEndScreenBackgroundObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "EndScreen");
}{for(var i = 0, len = gdjs.LevelCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEndScreenBackgroundObjects2[i].setOpacity(130);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.LevelCode.GDPlayer2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.LevelCode.GDPortalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17115900);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}
{ //Subevents
gdjs.LevelCode.eventsList32(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndScreen");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BoundaryJumpThrough"), gdjs.LevelCode.GDBoundaryJumpThroughObjects3);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.LevelCode.GDLeftBoundaryObjects3);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.LevelCode.GDRightBoundaryObjects3);
{for(var i = 0, len = gdjs.LevelCode.GDLeftBoundaryObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDLeftBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.LevelCode.GDRightBoundaryObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDRightBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.LevelCode.GDBoundaryJumpThroughObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDBoundaryJumpThroughObjects3[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BottomBoundary"), gdjs.LevelCode.GDBottomBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.LevelCode.GDLeftBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.LevelCode.GDRightBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopBoundary"), gdjs.LevelCode.GDTopBoundaryObjects2);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (( gdjs.LevelCode.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDLeftBoundaryObjects2[0].getPointX("")) + (( gdjs.LevelCode.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDLeftBoundaryObjects2[0].getWidth()), (( gdjs.LevelCode.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDTopBoundaryObjects2[0].getPointY("")) + (( gdjs.LevelCode.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDTopBoundaryObjects2[0].getHeight()), (( gdjs.LevelCode.GDRightBoundaryObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDRightBoundaryObjects2[0].getPointX("")), (( gdjs.LevelCode.GDBottomBoundaryObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDBottomBoundaryObjects2[0].getPointY("")), "", 0);
}}

}


};gdjs.LevelCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "crickets.aac", true, 30, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.LevelCode.GDBackgroundPlantsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Clouds"), gdjs.LevelCode.GDCloudsObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDBackgroundPlantsObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBackgroundPlantsObjects2[i].setWidth(gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.LevelCode.GDBackgroundPlantsObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBackgroundPlantsObjects2[i].setXOffset(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) / 3 + 780);
}
}{for(var i = 0, len = gdjs.LevelCode.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDCloudsObjects2[i].setX(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.LevelCode.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDCloudsObjects2[i].setWidth(gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.LevelCode.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDCloudsObjects2[i].setXOffset(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) * 1.2);
}
}}

}


};gdjs.LevelCode.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PRIDE_POWER"), gdjs.LevelCode.GDPRIDE_9595POWERObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDPRIDE_9595POWERObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPRIDE_9595POWERObjects2[i].setString("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects1Objects = Hashtable.newFrom({"Portal": gdjs.LevelCode.GDPortalObjects1});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects1});
gdjs.LevelCode.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "door.aac", 0, true, 100, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.LevelCode.GDPortalObjects1);
{gdjs.evtsExt__VolumeFalloff__SetVolumeFalloff.func(runtimeScene, 0, "Sound", gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPortalObjects1Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects1Objects, 0, 20, 750, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LevelCode.eventsList42 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList38(runtimeScene);
}


{


gdjs.LevelCode.eventsList39(runtimeScene);
}


{


gdjs.LevelCode.eventsList40(runtimeScene);
}


{


gdjs.LevelCode.eventsList41(runtimeScene);
}


};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects1});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects1});
gdjs.LevelCode.eventsList43 = function(runtimeScene) {

};gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects1});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.LevelCode.GDNewSprite2Objects1});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects1});
gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.LevelCode.GDPlayer2Objects1});
gdjs.LevelCode.eventsList44 = function(runtimeScene) {

};gdjs.LevelCode.eventsList45 = function(runtimeScene) {

{



}


{


gdjs.LevelCode.eventsList2(runtimeScene);
}


{


gdjs.LevelCode.eventsList10(runtimeScene);
}


{


gdjs.LevelCode.eventsList16(runtimeScene);
}


{


gdjs.LevelCode.eventsList23(runtimeScene);
}


{


gdjs.LevelCode.eventsList30(runtimeScene);
}


{


gdjs.LevelCode.eventsList37(runtimeScene);
}


{


gdjs.LevelCode.eventsList42(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber() == 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17136540);
}
}
if (isConditionTrue_0) {
gdjs.LevelCode.GDPlayerObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects1Objects, 104, -(6), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber() == 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17137348);
}
}
if (isConditionTrue_0) {
gdjs.LevelCode.GDPlayer2Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects1Objects, 104, -(6), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.LevelCode.GDPlayer2Objects1);
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects1[i].getBehavior("Scale").setScale(0.7);
}
}{for(var i = 0, len = gdjs.LevelCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayer2Objects1[i].getBehavior("Scale").setScale(0.8);
}
}}

}


{


gdjs.LevelCode.eventsList43(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.LevelCode.GDNewSprite2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects1Objects, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDNewSprite2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17139548);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PixelHeartBar"), gdjs.LevelCode.GDPixelHeartBarObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDPixelHeartBarObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPixelHeartBarObjects1[i].SetValue(gdjs.LevelCode.GDPixelHeartBarObjects1[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Hit 4.aac", false, 80, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PixelHeartBar"), gdjs.LevelCode.GDPixelHeartBarObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelCode.GDPixelHeartBarObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPixelHeartBarObjects1[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LevelCode.GDPixelHeartBarObjects1[k] = gdjs.LevelCode.GDPixelHeartBarObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDPixelHeartBarObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17141172);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.LevelCode.GDPlayer2Objects1);
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayerObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_9546LevelCode_9546GDPlayer2Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}}

}


{


gdjs.LevelCode.eventsList44(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.LevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LevelCode.GDPlatform1Objects1.length = 0;
gdjs.LevelCode.GDPlatform1Objects2.length = 0;
gdjs.LevelCode.GDPlatform1Objects3.length = 0;
gdjs.LevelCode.GDPlatform1Objects4.length = 0;
gdjs.LevelCode.GDPlatform1Objects5.length = 0;
gdjs.LevelCode.GDPlatform2Objects1.length = 0;
gdjs.LevelCode.GDPlatform2Objects2.length = 0;
gdjs.LevelCode.GDPlatform2Objects3.length = 0;
gdjs.LevelCode.GDPlatform2Objects4.length = 0;
gdjs.LevelCode.GDPlatform2Objects5.length = 0;
gdjs.LevelCode.GDPlatform3Objects1.length = 0;
gdjs.LevelCode.GDPlatform3Objects2.length = 0;
gdjs.LevelCode.GDPlatform3Objects3.length = 0;
gdjs.LevelCode.GDPlatform3Objects4.length = 0;
gdjs.LevelCode.GDPlatform3Objects5.length = 0;
gdjs.LevelCode.GDPlatform4Objects1.length = 0;
gdjs.LevelCode.GDPlatform4Objects2.length = 0;
gdjs.LevelCode.GDPlatform4Objects3.length = 0;
gdjs.LevelCode.GDPlatform4Objects4.length = 0;
gdjs.LevelCode.GDPlatform4Objects5.length = 0;
gdjs.LevelCode.GDPortalObjects1.length = 0;
gdjs.LevelCode.GDPortalObjects2.length = 0;
gdjs.LevelCode.GDPortalObjects3.length = 0;
gdjs.LevelCode.GDPortalObjects4.length = 0;
gdjs.LevelCode.GDPortalObjects5.length = 0;
gdjs.LevelCode.GDCheckpointObjects1.length = 0;
gdjs.LevelCode.GDCheckpointObjects2.length = 0;
gdjs.LevelCode.GDCheckpointObjects3.length = 0;
gdjs.LevelCode.GDCheckpointObjects4.length = 0;
gdjs.LevelCode.GDCheckpointObjects5.length = 0;
gdjs.LevelCode.GDLadderObjects1.length = 0;
gdjs.LevelCode.GDLadderObjects2.length = 0;
gdjs.LevelCode.GDLadderObjects3.length = 0;
gdjs.LevelCode.GDLadderObjects4.length = 0;
gdjs.LevelCode.GDLadderObjects5.length = 0;
gdjs.LevelCode.GDFlyObjects1.length = 0;
gdjs.LevelCode.GDFlyObjects2.length = 0;
gdjs.LevelCode.GDFlyObjects3.length = 0;
gdjs.LevelCode.GDFlyObjects4.length = 0;
gdjs.LevelCode.GDFlyObjects5.length = 0;
gdjs.LevelCode.GDCoinObjects1.length = 0;
gdjs.LevelCode.GDCoinObjects2.length = 0;
gdjs.LevelCode.GDCoinObjects3.length = 0;
gdjs.LevelCode.GDCoinObjects4.length = 0;
gdjs.LevelCode.GDCoinObjects5.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects1.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects2.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects3.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects4.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects5.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects1.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects2.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects3.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects4.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects5.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects1.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects2.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects3.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects4.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects5.length = 0;
gdjs.LevelCode.GDDustParticleObjects1.length = 0;
gdjs.LevelCode.GDDustParticleObjects2.length = 0;
gdjs.LevelCode.GDDustParticleObjects3.length = 0;
gdjs.LevelCode.GDDustParticleObjects4.length = 0;
gdjs.LevelCode.GDDustParticleObjects5.length = 0;
gdjs.LevelCode.GDCloudsObjects1.length = 0;
gdjs.LevelCode.GDCloudsObjects2.length = 0;
gdjs.LevelCode.GDCloudsObjects3.length = 0;
gdjs.LevelCode.GDCloudsObjects4.length = 0;
gdjs.LevelCode.GDCloudsObjects5.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects1.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects2.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects3.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects4.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects5.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects1.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects2.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects3.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects4.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects5.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects1.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects2.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects3.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects4.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects5.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects1.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects2.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects3.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects4.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects5.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects1.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects2.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects3.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects4.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects5.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects5.length = 0;
gdjs.LevelCode.GDMoonObjects1.length = 0;
gdjs.LevelCode.GDMoonObjects2.length = 0;
gdjs.LevelCode.GDMoonObjects3.length = 0;
gdjs.LevelCode.GDMoonObjects4.length = 0;
gdjs.LevelCode.GDMoonObjects5.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects1.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects2.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects3.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects4.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects5.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects1.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects2.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects3.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects4.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects5.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects1.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects2.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects3.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects4.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects5.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects1.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects2.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects3.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects4.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects5.length = 0;
gdjs.LevelCode.GDJoystickObjects1.length = 0;
gdjs.LevelCode.GDJoystickObjects2.length = 0;
gdjs.LevelCode.GDJoystickObjects3.length = 0;
gdjs.LevelCode.GDJoystickObjects4.length = 0;
gdjs.LevelCode.GDJoystickObjects5.length = 0;
gdjs.LevelCode.GDJumpButtonObjects1.length = 0;
gdjs.LevelCode.GDJumpButtonObjects2.length = 0;
gdjs.LevelCode.GDJumpButtonObjects3.length = 0;
gdjs.LevelCode.GDJumpButtonObjects4.length = 0;
gdjs.LevelCode.GDJumpButtonObjects5.length = 0;
gdjs.LevelCode.GDTrumpObjects1.length = 0;
gdjs.LevelCode.GDTrumpObjects2.length = 0;
gdjs.LevelCode.GDTrumpObjects3.length = 0;
gdjs.LevelCode.GDTrumpObjects4.length = 0;
gdjs.LevelCode.GDTrumpObjects5.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects1.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects2.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects3.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects4.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects5.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects1.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects2.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects3.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects4.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects5.length = 0;
gdjs.LevelCode.GDFly2Objects1.length = 0;
gdjs.LevelCode.GDFly2Objects2.length = 0;
gdjs.LevelCode.GDFly2Objects3.length = 0;
gdjs.LevelCode.GDFly2Objects4.length = 0;
gdjs.LevelCode.GDFly2Objects5.length = 0;
gdjs.LevelCode.GDNewSpriteObjects1.length = 0;
gdjs.LevelCode.GDNewSpriteObjects2.length = 0;
gdjs.LevelCode.GDNewSpriteObjects3.length = 0;
gdjs.LevelCode.GDNewSpriteObjects4.length = 0;
gdjs.LevelCode.GDNewSpriteObjects5.length = 0;
gdjs.LevelCode.GDheart1Objects1.length = 0;
gdjs.LevelCode.GDheart1Objects2.length = 0;
gdjs.LevelCode.GDheart1Objects3.length = 0;
gdjs.LevelCode.GDheart1Objects4.length = 0;
gdjs.LevelCode.GDheart1Objects5.length = 0;
gdjs.LevelCode.GDheart2Objects1.length = 0;
gdjs.LevelCode.GDheart2Objects2.length = 0;
gdjs.LevelCode.GDheart2Objects3.length = 0;
gdjs.LevelCode.GDheart2Objects4.length = 0;
gdjs.LevelCode.GDheart2Objects5.length = 0;
gdjs.LevelCode.GDheart3Objects1.length = 0;
gdjs.LevelCode.GDheart3Objects2.length = 0;
gdjs.LevelCode.GDheart3Objects3.length = 0;
gdjs.LevelCode.GDheart3Objects4.length = 0;
gdjs.LevelCode.GDheart3Objects5.length = 0;
gdjs.LevelCode.GDNewSprite2Objects1.length = 0;
gdjs.LevelCode.GDNewSprite2Objects2.length = 0;
gdjs.LevelCode.GDNewSprite2Objects3.length = 0;
gdjs.LevelCode.GDNewSprite2Objects4.length = 0;
gdjs.LevelCode.GDNewSprite2Objects5.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects1.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects2.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects3.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects4.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects5.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects1.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects2.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects3.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects4.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects5.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects1.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects2.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects3.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects4.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects5.length = 0;
gdjs.LevelCode.GDRetryButtonObjects1.length = 0;
gdjs.LevelCode.GDRetryButtonObjects2.length = 0;
gdjs.LevelCode.GDRetryButtonObjects3.length = 0;
gdjs.LevelCode.GDRetryButtonObjects4.length = 0;
gdjs.LevelCode.GDRetryButtonObjects5.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects1.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects2.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects3.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects4.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects5.length = 0;
gdjs.LevelCode.GDDonateObjects1.length = 0;
gdjs.LevelCode.GDDonateObjects2.length = 0;
gdjs.LevelCode.GDDonateObjects3.length = 0;
gdjs.LevelCode.GDDonateObjects4.length = 0;
gdjs.LevelCode.GDDonateObjects5.length = 0;
gdjs.LevelCode.GDPlayerObjects1.length = 0;
gdjs.LevelCode.GDPlayerObjects2.length = 0;
gdjs.LevelCode.GDPlayerObjects3.length = 0;
gdjs.LevelCode.GDPlayerObjects4.length = 0;
gdjs.LevelCode.GDPlayerObjects5.length = 0;
gdjs.LevelCode.GDPlayer2Objects1.length = 0;
gdjs.LevelCode.GDPlayer2Objects2.length = 0;
gdjs.LevelCode.GDPlayer2Objects3.length = 0;
gdjs.LevelCode.GDPlayer2Objects4.length = 0;
gdjs.LevelCode.GDPlayer2Objects5.length = 0;

gdjs.LevelCode.eventsList45(runtimeScene);
gdjs.LevelCode.GDPlatform1Objects1.length = 0;
gdjs.LevelCode.GDPlatform1Objects2.length = 0;
gdjs.LevelCode.GDPlatform1Objects3.length = 0;
gdjs.LevelCode.GDPlatform1Objects4.length = 0;
gdjs.LevelCode.GDPlatform1Objects5.length = 0;
gdjs.LevelCode.GDPlatform2Objects1.length = 0;
gdjs.LevelCode.GDPlatform2Objects2.length = 0;
gdjs.LevelCode.GDPlatform2Objects3.length = 0;
gdjs.LevelCode.GDPlatform2Objects4.length = 0;
gdjs.LevelCode.GDPlatform2Objects5.length = 0;
gdjs.LevelCode.GDPlatform3Objects1.length = 0;
gdjs.LevelCode.GDPlatform3Objects2.length = 0;
gdjs.LevelCode.GDPlatform3Objects3.length = 0;
gdjs.LevelCode.GDPlatform3Objects4.length = 0;
gdjs.LevelCode.GDPlatform3Objects5.length = 0;
gdjs.LevelCode.GDPlatform4Objects1.length = 0;
gdjs.LevelCode.GDPlatform4Objects2.length = 0;
gdjs.LevelCode.GDPlatform4Objects3.length = 0;
gdjs.LevelCode.GDPlatform4Objects4.length = 0;
gdjs.LevelCode.GDPlatform4Objects5.length = 0;
gdjs.LevelCode.GDPortalObjects1.length = 0;
gdjs.LevelCode.GDPortalObjects2.length = 0;
gdjs.LevelCode.GDPortalObjects3.length = 0;
gdjs.LevelCode.GDPortalObjects4.length = 0;
gdjs.LevelCode.GDPortalObjects5.length = 0;
gdjs.LevelCode.GDCheckpointObjects1.length = 0;
gdjs.LevelCode.GDCheckpointObjects2.length = 0;
gdjs.LevelCode.GDCheckpointObjects3.length = 0;
gdjs.LevelCode.GDCheckpointObjects4.length = 0;
gdjs.LevelCode.GDCheckpointObjects5.length = 0;
gdjs.LevelCode.GDLadderObjects1.length = 0;
gdjs.LevelCode.GDLadderObjects2.length = 0;
gdjs.LevelCode.GDLadderObjects3.length = 0;
gdjs.LevelCode.GDLadderObjects4.length = 0;
gdjs.LevelCode.GDLadderObjects5.length = 0;
gdjs.LevelCode.GDFlyObjects1.length = 0;
gdjs.LevelCode.GDFlyObjects2.length = 0;
gdjs.LevelCode.GDFlyObjects3.length = 0;
gdjs.LevelCode.GDFlyObjects4.length = 0;
gdjs.LevelCode.GDFlyObjects5.length = 0;
gdjs.LevelCode.GDCoinObjects1.length = 0;
gdjs.LevelCode.GDCoinObjects2.length = 0;
gdjs.LevelCode.GDCoinObjects3.length = 0;
gdjs.LevelCode.GDCoinObjects4.length = 0;
gdjs.LevelCode.GDCoinObjects5.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects1.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects2.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects3.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects4.length = 0;
gdjs.LevelCode.GDMonsterParticlesObjects5.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects1.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects2.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects3.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects4.length = 0;
gdjs.LevelCode.GDCoinParticlesObjects5.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects1.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects2.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects3.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects4.length = 0;
gdjs.LevelCode.GDDoorParticlesObjects5.length = 0;
gdjs.LevelCode.GDDustParticleObjects1.length = 0;
gdjs.LevelCode.GDDustParticleObjects2.length = 0;
gdjs.LevelCode.GDDustParticleObjects3.length = 0;
gdjs.LevelCode.GDDustParticleObjects4.length = 0;
gdjs.LevelCode.GDDustParticleObjects5.length = 0;
gdjs.LevelCode.GDCloudsObjects1.length = 0;
gdjs.LevelCode.GDCloudsObjects2.length = 0;
gdjs.LevelCode.GDCloudsObjects3.length = 0;
gdjs.LevelCode.GDCloudsObjects4.length = 0;
gdjs.LevelCode.GDCloudsObjects5.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects1.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects2.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects3.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects4.length = 0;
gdjs.LevelCode.GDBackgroundPlantsObjects5.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects1.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects2.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects3.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects4.length = 0;
gdjs.LevelCode.GDLeftBoundaryObjects5.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects1.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects2.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects3.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects4.length = 0;
gdjs.LevelCode.GDRightBoundaryObjects5.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects1.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects2.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects3.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects4.length = 0;
gdjs.LevelCode.GDTopBoundaryObjects5.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects1.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects2.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects3.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects4.length = 0;
gdjs.LevelCode.GDBottomBoundaryObjects5.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.LevelCode.GDBoundaryJumpThroughObjects5.length = 0;
gdjs.LevelCode.GDMoonObjects1.length = 0;
gdjs.LevelCode.GDMoonObjects2.length = 0;
gdjs.LevelCode.GDMoonObjects3.length = 0;
gdjs.LevelCode.GDMoonObjects4.length = 0;
gdjs.LevelCode.GDMoonObjects5.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects1.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects2.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects3.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects4.length = 0;
gdjs.LevelCode.GDEndScreenBackgroundObjects5.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects1.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects2.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects3.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects4.length = 0;
gdjs.LevelCode.GDEndScreenHeaderObjects5.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects1.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects2.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects3.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects4.length = 0;
gdjs.LevelCode.GDEndScreenBestTextObjects5.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects1.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects2.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects3.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects4.length = 0;
gdjs.LevelCode.GDEndScreenChallengeTextObjects5.length = 0;
gdjs.LevelCode.GDJoystickObjects1.length = 0;
gdjs.LevelCode.GDJoystickObjects2.length = 0;
gdjs.LevelCode.GDJoystickObjects3.length = 0;
gdjs.LevelCode.GDJoystickObjects4.length = 0;
gdjs.LevelCode.GDJoystickObjects5.length = 0;
gdjs.LevelCode.GDJumpButtonObjects1.length = 0;
gdjs.LevelCode.GDJumpButtonObjects2.length = 0;
gdjs.LevelCode.GDJumpButtonObjects3.length = 0;
gdjs.LevelCode.GDJumpButtonObjects4.length = 0;
gdjs.LevelCode.GDJumpButtonObjects5.length = 0;
gdjs.LevelCode.GDTrumpObjects1.length = 0;
gdjs.LevelCode.GDTrumpObjects2.length = 0;
gdjs.LevelCode.GDTrumpObjects3.length = 0;
gdjs.LevelCode.GDTrumpObjects4.length = 0;
gdjs.LevelCode.GDTrumpObjects5.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects1.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects2.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects3.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects4.length = 0;
gdjs.LevelCode.GDYellowJellyButtonObjects5.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects1.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects2.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects3.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects4.length = 0;
gdjs.LevelCode.GDBackgroundPlants2Objects5.length = 0;
gdjs.LevelCode.GDFly2Objects1.length = 0;
gdjs.LevelCode.GDFly2Objects2.length = 0;
gdjs.LevelCode.GDFly2Objects3.length = 0;
gdjs.LevelCode.GDFly2Objects4.length = 0;
gdjs.LevelCode.GDFly2Objects5.length = 0;
gdjs.LevelCode.GDNewSpriteObjects1.length = 0;
gdjs.LevelCode.GDNewSpriteObjects2.length = 0;
gdjs.LevelCode.GDNewSpriteObjects3.length = 0;
gdjs.LevelCode.GDNewSpriteObjects4.length = 0;
gdjs.LevelCode.GDNewSpriteObjects5.length = 0;
gdjs.LevelCode.GDheart1Objects1.length = 0;
gdjs.LevelCode.GDheart1Objects2.length = 0;
gdjs.LevelCode.GDheart1Objects3.length = 0;
gdjs.LevelCode.GDheart1Objects4.length = 0;
gdjs.LevelCode.GDheart1Objects5.length = 0;
gdjs.LevelCode.GDheart2Objects1.length = 0;
gdjs.LevelCode.GDheart2Objects2.length = 0;
gdjs.LevelCode.GDheart2Objects3.length = 0;
gdjs.LevelCode.GDheart2Objects4.length = 0;
gdjs.LevelCode.GDheart2Objects5.length = 0;
gdjs.LevelCode.GDheart3Objects1.length = 0;
gdjs.LevelCode.GDheart3Objects2.length = 0;
gdjs.LevelCode.GDheart3Objects3.length = 0;
gdjs.LevelCode.GDheart3Objects4.length = 0;
gdjs.LevelCode.GDheart3Objects5.length = 0;
gdjs.LevelCode.GDNewSprite2Objects1.length = 0;
gdjs.LevelCode.GDNewSprite2Objects2.length = 0;
gdjs.LevelCode.GDNewSprite2Objects3.length = 0;
gdjs.LevelCode.GDNewSprite2Objects4.length = 0;
gdjs.LevelCode.GDNewSprite2Objects5.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects1.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects2.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects3.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects4.length = 0;
gdjs.LevelCode.GDPixelHeartBarObjects5.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects1.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects2.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects3.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects4.length = 0;
gdjs.LevelCode.GDEndScreenSubHeaderObjects5.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects1.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects2.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects3.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects4.length = 0;
gdjs.LevelCode.GDEndScreenRetryTextObjects5.length = 0;
gdjs.LevelCode.GDRetryButtonObjects1.length = 0;
gdjs.LevelCode.GDRetryButtonObjects2.length = 0;
gdjs.LevelCode.GDRetryButtonObjects3.length = 0;
gdjs.LevelCode.GDRetryButtonObjects4.length = 0;
gdjs.LevelCode.GDRetryButtonObjects5.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects1.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects2.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects3.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects4.length = 0;
gdjs.LevelCode.GDPRIDE_9595POWERObjects5.length = 0;
gdjs.LevelCode.GDDonateObjects1.length = 0;
gdjs.LevelCode.GDDonateObjects2.length = 0;
gdjs.LevelCode.GDDonateObjects3.length = 0;
gdjs.LevelCode.GDDonateObjects4.length = 0;
gdjs.LevelCode.GDDonateObjects5.length = 0;
gdjs.LevelCode.GDPlayerObjects1.length = 0;
gdjs.LevelCode.GDPlayerObjects2.length = 0;
gdjs.LevelCode.GDPlayerObjects3.length = 0;
gdjs.LevelCode.GDPlayerObjects4.length = 0;
gdjs.LevelCode.GDPlayerObjects5.length = 0;
gdjs.LevelCode.GDPlayer2Objects1.length = 0;
gdjs.LevelCode.GDPlayer2Objects2.length = 0;
gdjs.LevelCode.GDPlayer2Objects3.length = 0;
gdjs.LevelCode.GDPlayer2Objects4.length = 0;
gdjs.LevelCode.GDPlayer2Objects5.length = 0;


return;

}

gdjs['LevelCode'] = gdjs.LevelCode;
